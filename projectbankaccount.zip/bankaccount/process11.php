<?php


     if(isset($_POST['submit']))
     {
        $userid=$_POST['userid'];
        $password=$_POST['password'];

        include("connect.php");

            $sql="select id,password from admin where id='$userid' and password='$password'";
            $sql1="select userid,password from  user where userid='$userid' and password='$password'";
            $r=mysqli_query($con,$sql);
            $r1=mysqli_query($con,$sql1);



            if(mysqli_num_rows($r)>0)
            {
                $_SESSION['id']=$userid;
                $_SESSION['admin_login_status']="loged in";
                header("Location:admin/index.php?");
            }

            else if(mysqli_num_rows($r1)>0)
            {
                $_SESSION['userid']=$userid;
                $_SESSION['employee_login_status']="loged in";
                header("Location:user/index.php?id=$userid");
            }
            else
            {
                echo "<p style='color: red;'>Incorrect UserId or Password</p>";
            }
     }




?>
