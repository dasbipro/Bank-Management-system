<?php
include("connect.php");
 $userid=$_SESSION['userid'];
 $in_sql = "SELECT sum(amountdeposted) FROM deposit_details where userid = $userid";
 $ru_sql = mysqli_query($con, $in_sql);
 $temp = mysqli_affected_rows($con);
 if($temp){
     $rows = mysqli_fetch_array($ru_sql);
     $balance = $rows['balance'];
     $amount = 0;
     if($amount==0){
         $total = $balance + $amount ;

         $ins_sql = "UPDATE account
                     SET balance = $total
                     WHERE userid = '$userid'";
         $run_sql = mysqli_query($con, $ins_sql);
         $temp1 = mysqli_affected_rows($con);



if($temp1){

            $success = "Deposit money successfully!";
        }else{
            $success = "Userid  doesn't match!";
        }
    }





?>