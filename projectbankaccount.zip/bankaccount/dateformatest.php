<?php 

$date = new DateTime($dt2);
$dt2=$date->format('m/d/Y');
echo $date;

?>