$(function(){
	$("#firstname_error_msg").hide();
    $("#firstname_error_msg1").hide();
    $("#lastname_error_msg").hide();
	$("#lastname_error_msg1").hide();
	$("#address_error_msg").hide();
	$("#address_error_msg1").hide();
	$("#email_error_msg").hide();
	$("#email_error_msg1").hide();
	$("#password_error_msg").hide();
	$("#password_error_msg1").hide();
	$("#confirm_pass_error_msg").hide();

	var error_firstname=false;
	var error_address=false;
	var error_email=false;
	var error_password=false;
	var error_confirm_password=false;


	$("#firstname").focusout(function(){
		check_firstname()
    });
    $("#lastname").focusout(function(){
		check_lastname()
	});
	$("#address").focusout(function(){
		check_address()
	});

	$("#email").focusout(function(){
		check_email()
	});
	$("#password").focusout(function(){
		check_password()
	});
	$("#confirm_password").focusout(function(){
		check_confirm_password()
	});

   function check_firstname(){
        var firstname_val=$("#firstname").val();
        var firstname_length=$("#firstname").val().length;
        var firstnamePattern=/^[a-zA-Z0-9_-]+$/;
        if(firstname_val<1){
            $("#firstname_error_msg1").hide();
            $("#firstname_error_msg").html("The field is required!");
             $("#firstname_error_msg").show();
             error_firstname=true;
        }
        else if(!firstnamePattern.test(firstname_val)){
            $("#firstname_error_msg1").hide();
            $("#firstname_error_msg").html("Your firstname is not valid!");
             $("#firstname_error_msg").show();
             error_firstname=true;
        }
        else{
            if(firstname_length<5 || firstname_length>20 ){
                $("#firstname_error_msg1").hide();
                $("#firstname_error_msg").html("Should be between 5 to 20 characters");
                $("#firstname_error_msg").show();
                error_firstname=true;
           }
           else{
                $("#firstname_error_msg").hide();
                error_firstname=false;
           }
        }
       if(error_firstname==false)
       {
            $.ajax({
                type:"POST",
                url:"action.php",
                data:'firstname='+firstname_val,
                success:function(data){
                    if(data == 'Yes'){
                        //console.log("yes");
                        $("#firstname_error_msg11").html('<span id="firstname_error_msg1" class="error_form pl-1">It is already exist, Try again!</span>');
                        //$("#username_error_msg1").show();
                        error_username=true;
                    }
                    else{
                        $("#firstname_error_msg1").hide();
                        //console.log("No");
                        error_firstname=false;
                    }
                    // else{
                    //     console.log("Not working");
                    //     error_username=false;
                    // }
                }
            });
       }   
    }
    function check_lastname(){
        var lastname_val=$("#lastname").val();
        var lastname_length=$("#lastname").val().length;
        var lastnamePattern=/^[a-zA-Z0-9_-]+$/;
        if(lastname_val<1){
            $("#lastname_error_msg1").hide();
            $("#lastname_error_msg").html("The field is required!");
             $("#lastname_error_msg").show();
             error_lastname=true;
        }
        else if(!lastnamePattern.test(lastname_val)){
            $("#lastname_error_msg1").hide();
            $("#lastname_error_msg").html("Your lastname is not valid!");
             $("#lastname_error_msg").show();
             error_lastname=true;
        }
        else{
            if(lastname_length<5 || lastname_length>20 ){
                $("#lastname_error_msg1").hide();
                $("#lastname_error_msg").html("Should be between 5 to 20 characters");
                $("#lastname_error_msg").show();
                error_lastname=true;
           }
           else{
                $("#lastname_error_msg").hide();
                error_lastname=false;
           }
        }
       if(error_v==false)
       {
            $.ajax({
                type:"POST",
                url:"action.php",
                data:'lastname='+lastname_val,
                success:function(data){
                    if(data == 'Yes'){
                        //console.log("yes");
                        $("#lastname_error_msg11").html('<span id="firstname_error_msg1" class="error_form pl-1">It is already exist, Try again!</span>');
                        //$("#username_error_msg1").show();
                        error_lastname=true;
                    }
                    else{
                        $("#lastname_error_msg1").hide();
                        //console.log("No");
                        error_lastname=false;
                    }
                    // else{
                    //     console.log("Not working");
                    //     error_username=false;
                    // }
                }
            });
       }   
    }
     function check_address(){
        var address_val=$("#address").val();
        var address_length=$("#address").val().length;
          if(address_val<1){
            $("#address_error_msg1").hide();
            $("#address_error_msg").html("The address field is required!");
             $("#address_error_msg").show();
             error_address=true;
        }
        else{
            if(address_length<5 || address_length>20 ){
                $("#address_error_msg1").hide();
                $("#address_error_msg").html("Should be between 5 to 20 characters");
                $("#address_error_msg").show();
                error_address=true;
           }
           else{
                $("#address_error_msg").hide();
                error_address=false;
           }
        }
       if(error_address==false)
       {
            $.ajax({
                type:"POST",
                url:"action.php",
                data:'address='+address_val,
                success:function(data){
                    if(data == 'Yes'){
                        //console.log("yes");
                        $("#address_error_msg11").html('<span id="address_error_msg1" class="error_form pl-1">It is already exist, Try again!</span>');
                        //$("#username_error_msg1").show();
                        error_address=true;
                    }
                    else{
                        $("#address_error_msg1").hide();
                        //console.log("No");
                        error_address=false;
                    }
                    // else{
                    //     console.log("Not working");
                    //     error_username=false;
                    // }
                }
            });
       }   
    }

   function check_email(){
        var pattern=new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
        var email=$("#email").val();
        if(email<1){
            $("#email_error_msg1").hide();
            $("#email_error_msg").html("The feild is required!");
            $("#email_error_msg").show();
            error_email=true;
        }
        else if(pattern.test($("#email").val())){
            $("#email_error_msg").hide();
            error_email=false;
        }
        else{
            $("#email_error_msg1").hide();
            $("#email_error_msg").html("Invalid email address!!");
            $("#email_error_msg").show();
            error_email=true;
        }
        if(error_email==false){
            $.ajax({
                type:"POST",
                url:"action.php",
                data:'email='+email,
                success:function(data){
                    if(data == 'Yes'){
                        $("#email_error_msg").html('<span id="email_error_msg1" class="error_form pl-1">The email is already exist, Try again!</span>');
                        error_email=true;
                    }
                    else{
                        $("#email_error_msg1").hide();
                        error_email=false;
                    }
                }
            });
        }
    }
 function check_password(){
        var password=$("#password").val();
        var password_length =$("#password").val().length;
        var patternPass=new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])");

        //https://www.thepolyglotdeveloper.com/2015/05/use-regex-to-test-password-strength-in-javascript/ (?=.{8,})

        if(password<1){
            $("#password_error_msg1").hide();
            $("#password_error_msg").html("The feild is required!");
            $("#password_error_msg").show();
            error_password=true;
        }
        else if(!patternPass.test(password)){
            $("#password_error_msg1").hide();
            $("#password_error_msg").html("Must have A-Z, a-z, 0-9 and symbols!");
             $("#password_error_msg").show();
             error_username=true;
        }
        else if(password_length<8){
                $("#password_error_msg1").hide();
                $("#password_error_msg").html("Should be min 8 characters");
                $("#password_error_msg").show();
                error_password=true;
           }
           else{
               $("#password_error_msg").hide();
               error_password=false;
           }
        
        if(error_password==false){
            $.ajax({
                type:"POST",
                url:"action.php",
                data:'password='+password,
                success:function(data){
                    if(data == 'Yes'){
                        $("#password_error_msg11").html('<span id="password_error_msg1" class="error_form pl-1">The Password is already exist, Try again!</span>');
                        error_password=true;
                    }
                    else{
                        $("#password_error_msg1").hide();
                        error_password=false;
                    }
                }
            });
        }
        
    }       function check_confirm_password(){
        var password=$("#password").val();
        var confirm_password=$("#confirm_password").val();
        if(confirm_password<1){
            $("#confirm_pass_error_msg").html("The feild is required!");
            $("#confirm_pass_error_msg").show();
            error_confirm_password=true;
        }
        else if(password!=confirm_password){
             $("#confirm_pass_error_msg").html("Password did not match!");
             $("#confirm_pass_error_msg").show();
             error_confirm_password=true;
        }
        else{
            $("#confirm_pass_error_msg").hide();
            error_confirm_password=false;
        }
    }
	$("#myform").submit(function(){
		
		if(error_firstname==false && error_lastname==false  && error_address==false && error_email==false && error_password==false && error_confirm_password==false ){
		return true;

	}else{
		return false;

	}
	});
});
