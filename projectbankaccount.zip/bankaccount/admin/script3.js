
$('document').ready(function(){
    var accountno_state = false;
    var customerid_state = false;
    var nid_state = false;
   
    $('#accountno').on('blur', function(){
     var accountno = $('#accountno').val();
     if (accountno == '') {
       accountno_state = false;
       return;
     }
     $.ajax({
       url: 'account.php',
       type: 'post',
       data: {
         'accountno_check' : 1,
         'accountno' : accountno,
       },
       success: function(response){
         if (response == 'taken' ) {
           accountno_state = false;
           $('#accountno').parent().removeClass();
           $('#accountno').parent().addClass("form_error");
           $('#accountno').siblings("span").text('Sorry...accountno already taken');
         }else if (response == 'not_taken') {
           accountno_state = true;
           $('#accountno').parent().removeClass();
           $('#accountno').parent().addClass("form_success");
           $('#accountno').siblings("span").text('accountnoS available');
         }
       }
     });
    });	
    $('#customerid').on('blur', function(){
     var customerid = $('#customerid').val();
     if (customerid == '') {
       customerid_state = false;
       return;
     }
     $.ajax({
       url: 'account.php',
       type: 'post',
       data: {
         'customerid_check' : 1,
         'customerid' : customerid,
       },
       success: function(response){
         if (response == 'taken' ) {
           customerid_state = false;
           $('#customerid').parent().removeClass();
           $('#customerid').parent().addClass("form_error");
           $('#customerid').siblings("span").text('Sorry... Userid already taken');
         }else if (response == 'not_taken') {
           customerid_state = true;
           $('#customerid').parent().removeClass();
           $('#customerid').parent().addClass("form_success");
           $('#customerid').siblings("span").text('Userid available');
         }
       }
     });
    });    	
    $('#nid').on('blur', function(){
        var nid = $('#nid').val();
        if (nid == '') {
          nid_state = false;
          return;
        }
        $.ajax({
          url: 'account.php',
          type: 'post',
          data: {
            'nid_check' : 1,
            'nid' : nid,
          },
          success: function(response){
            if (response == 'taken' ) {
              nid_state = false;
              $('#nid').parent().removeClass();
              $('#nid').parent().addClass("form_error");
              $('#nid').siblings("span").text('Sorry... nid already taken');
            }else if (response == 'not_taken') {
              nid_state = true;
              $('#nid').parent().removeClass();
              $('#nid').parent().addClass("form_success");
              $('#nid').siblings("span").text('Nid available');
            }
          }
        });
       });	
   
    $('#reg_btn').on('click', function(){
      var accountno = $('#accountno').val();
      var customerid = $('#customerid').val();
   
      var balance = $('#balance').val('');
      var accounttype = $('#account_type').val('');
      var nid = $('#nid').val();
     //var Date=$('#Date').val('');
      if (accountno_state == false || customerid_state == false || nid_state == false) {
       $('#error_msg').text('Fix the errors in the form first');
     }else{
         // proceed with form submission
         $.ajax({
           url: 'account.php',
           type: 'post',
           data: {
             'submit' : 1,
             'accountno' : accountno,
             'customerid' : customerid,
            
             'accounttype' : accounttype,
             'balance' : balance,
             'nid' : nid,
             
           },
           success: function(response){
             alert('user saved');
             $('#accountno').val('');
             $('#customerid').val('');
          
             $('#accounttype').val('');
             $('#balance').val('');
             $('#nid').val('');
             //$('#Date').val('');
           }
         });
      }
    });
   });
  
  