<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Bank">
    <meta name="keywords" content="Bank">
    <meta name="author" content="Brad Traversy">
		<title>Deposit Delete</title>
		<style>
			input[type='text'], input[type='password'], select{
				width: 380px;
				height: 20px;
				border: 1px solid black;
			}
			textarea {
				resize: none;
				border: 1px solid black;
			}
			input[type='submit'] {
				background: brown;
				color: white;
				border: 1px solid black;
				width: 380px;
				height: 25px;
			}
		</style>
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Sonali</span> Bank Limited</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php">Back to Home</a></li>



          </ul>
        </nav>
      </div>
    </header>

    <section id="main">
 <div class="container">


			<form action="deposit_total.php" method="post">
			<h2>Deposite Balance</h2><hr>


			</form>


			 <?php
			 session_start();



										include("connect.php");




												$ins_sql = "select * from deposit	WHERE Date between '2019-01-01' and '2019-01-17'";


			      					$run_sql = mysqli_query($con, $ins_sql);



			               	while(mysqli_fetch_array($run_sql){

			     					echo 	$success = "successfully!";









			       ?>
}
     </div>
</section>
			 <footer>
		     <p>
		Home | Webmail | Contact us | Site Map
		Copyright © 2019 Sonali Bank Limited.
		All rights reserved.</p>
		   </footer>
	</body>
</html>
