

<!DOCTYPE php>
<php lang="en">
<head>
<title>Bank Card Banking Category Flat Bootstrap Responsive Website Template | About :: w3layouts</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<meta name="keywords" content="Bank Card Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    
	
	<!-- css files -->
    <link rel="stylesheet" href="styles.css">
	<link href="css1.css" rel='stylesheet' type='text/css' />
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Niramit:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
	<!-- move top -->

  <script src="js/jquery.js"></script>
  <!--<script>window.jQuery || document.write('<script src="js/vendor/jquery-3.4.1.min.js"><\/script>')</script>-->
 


  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
 

</head>
<body>
<!-- header -->
<header>
<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-university"></span> Premier Bank </a></h1>
			</div>
			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
        <li class="active"><a href="index.php">Home</a></li>
		<li>
                <a href="#" class="animsition-link">Employee</a>
                <ul>
                  
                  <li><a href="employee.php">Create Employee</a></li>
				  <li><a href="employee_details.php">View Employee</a></li>
      </ul>
      </li>
	  <li>
                <a href="#" class="animsition-link">Bank</a>
                <ul>
                  
                  <li><a href="bank_details.php">Bank details</a></li>
				  <li class=""><a href="registered.php">View Registered User</a></li> 
      </ul>
      </li>

        <li>
                <a href="#" class="animsition-link">Account</a>
                <ul class="">
                  <li><a href="account.php">Create Account</a></li>
                  <li><a href="account_details.php">View Account</a></li>
      </ul>
      </li>
        <li>
                <a href="#" class="animsition-link">Deposit</a>
                <ul>
                  
                  <li><a href="deposit_details.php">View Deposit</a></li>
      </ul>
      </li>
	  <li>
                <a href="#" class="animsition-link">Withdraw</a>
                <ul>
                 
                  <li><a href="withdraw_details.php">View Withdraw</a></li>
      </ul>
      </li>
        
		<li class=""><a href="Log_out.php">Log Out</a></li>
        
				
				
			</ul>
		</nav>
		<!-- //nav -->
	</div>
		<!-- //nav -->
	</div>
</header>
<!-- //header -->

<!-- inner-banner -->
<section class="inner-banner" id="home">
	<div class="inner-layer">
		<div class="container">
		</div>
	</div>
</section>
<!-- //inner-banner -->

<!-- breadcrumb -->
<div class="breadcrumb-w3pvt">
	<div class="container">
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item">
				<a href="delete.php">Delete</a>
			</li>
			
			
		</ol>
	</nav>
	</div>
</div>

<!-- //breadcrumb -->

<!-- advantages and details -->
<section class="advantages pt-5">
	<div class="container pb-lg-5">
		<div class="row advantages_grids">
            <div class="col-sm-6">
			<form id="myform" action="delete.php" method="post" id="register_form">
			
       
    <div class="form-group">
        <label for="account_no" id="email-ariaLabel">Account No</label>
       <input type="text" name="account_no" class="form-control" placeholder="account_no" id="account_no" required="1">
	<span></span>	
	
	<div class="form-group">
        <label for="balance" id="email-ariaLabel">balance</label>
       <input type="text" name="balance" class="form-control" placeholder="balance" id="balanceo" required="1">
	<span></span>		

	<div class="form-group">
	<input type="submit" name="submit" id="reg_btn" value="submit" class="btn btn-success">
	</div>
    <div id="error_msg"></div>
</form>
	</div>		
	</div>	
		</section>
		<div>
		<?php
					include("connect.php");
					if(isset($_POST['submit']))
					{
            $account_no=$_POST['account_no'];
			$balance = $_POST['balance'];		
            if($balance=0){
					//	echo $pass;

					$ins_sql = "delete from account	WHERE account_no = '$account_no' AND balance='$balance'";
			      					$run_sql = mysqli_query($con, $ins_sql);



			               if($run_sql){

			     					echo	$success = "Deleted money successfully!";
									}
}}







			       ?>

     </div>
</section>
				


	

<!-- footer-top -->
<section class="footer-top pt-5">
	<div class="container">
		<div class="col">
			<div class="col-lg-3 col-sm-6 mb-4">
				<h3 class="my-sm-3 mb-2"><span class="fa mr-2 fa-mobile"></span> Mobile Apps</h3>
				<p class="mb-sm-4"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.</p>
			</div>
			<div class="col-lg-3 col-sm-6 mb-4">
				<h3 class="my-sm-3 mb-2"><span class="fa mr-2 fa-shield"></span> Security Tips</h3>
				<p class="mb-sm-4"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.</p>
			</div>
			<div class="col-lg-3 col-sm-6 mb-4">
				<h3 class="my-sm-3 mb-2"><span class="fa mr-2 fa-globe"></span> Various Branches</h3>
				<p class="mb-sm-4"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.</p>
			</div>
			<div class="col-lg-3 col-sm-6 mb-4">
				<h3 class="my-sm-3 mb-2"><span class="fa mr-2 fa-phone"></span> 24/7 Support</h3>
				<p class="mb-4"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.</p>
			</div>
		</div>
	</div>
</section>
<!-- //footer-top -->

<!-- footer -->
<footer class="footer py-5">
	<div class="container pt-lg-4">
		<div class="col">
			<div class="col-lg-3 col-sm-6 footer-top">
				<h4 class="mb-4 w3f_title">Contact Info</h4>
				<ul class="list-w3">
					<li><span class="fa mr-1 fa-map-marker"></span>2130 Fulton Street, San Diego, CA 94117-1080 USA</li>
					<li class="my-2"><span class="fa mr-1 fa-phone"></span>1-600-1234-567</li>
					<li class="my-2"><span class="fa mr-1 fa-phone"></span>1-600-1234-567</li>
					<li class=""><span class="fa mr-1 fa-envelope"></span><a href="mailto:info@example.com">info@example.com</a></li>
				</ul>
			</div>
			<div class="col-lg-3 col-sm-6 footv3-left mt-sm-0 mt-4">
				<h4 class="mb-4 w3f_title"> Share Holders</h4>
				<ul class="list-w3">
					<li class="my-2">
						<a href="#">
							Shareholders Information
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							Stock Information
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Financial Results
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Investors faq's
						</a>
					</li>
					<li>
						<a href="#">
							Regulatory Section
						</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-2 col-sm-4 mt-lg-0 mt-sm-5 mt-4">
				<h4 class="mb-4 w3f_title">Media Center</h4>
				<ul class="list-w3">
					<li class="my-2">
						<a href="#">
							Press Release
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							Vision & Values
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Winning Awards
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Banking
						</a>
					</li>
				</ul>
			</div>

			<div class="col-lg-2 col-sm-4 mt-lg-0 mt-sm-5 mt-4">
				<h4 class="mb-4 w3f_title">Resources</h4>
				<ul class="list-w3">
					<li class="my-2">
						<a href="#">
							24/7 Help Line
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							Nearest Branch
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Guidance
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Download
						</a>
					</li>
					<li>
						<a href="#">
							Mobile App
						</a>
					</li>
				</ul>
			</div>
			
			<div class="col-lg-2 col-sm-4 mt-lg-0 mt-sm-5 mt-4">
				<h4 class="mb-4 w3f_title">Other Links</h4>
				<ul class="list-w3">
					<li class="my-2">
						<a href="#">
							Careers
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							All faq's
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Bank Group
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Credit Cards
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Loans
						</a>
					</li>
				</ul>
			</div>
			
		</div>
	</div>
	<!-- //footer bottom -->
</footer>
<!-- //footer -->

<!-- middle -->
<section class="middle py-4">
	<div class="container">
		<p><strong class="mr-2">Our Offerings & Calculators:</strong> Personal loans, Home and car loans, loan calculators, Savings accounts, Credit cards, Insurance.</p>
		<p><strong class="mr-2">Bank Smart:</strong> Internet Banking, Online Banking, Cardless transactions, Fixed deposits, Pin generation, Card active status.</p>
	</div>
</section>
<!-- //middle -->

<!-- copyright -->
<section class="copy-right py-4">
	<div class="container">
		<div class="col">
			<div class="col-lg-7">
				<p class="">© 2019 Bank Card. All rights reserved | Design by
					<a href="http://w3layouts.com"> W3layouts.</a>
				</p>
			</div>
			<div class="col-lg-5 mt-lg-0 mt-3">
				<ul class="list-w3 d-sm-flex">
					<li>
						<a href="#">
							Privicy Policy
						</a>
					</li>
					<li class="mx-sm-4 mx-3">
						<a href="#">
							Terms & Conditions
						</a>
					</li>
					<li>
						<a href="#">
							Disclaimer.
						</a>
					</li>
					<li>
						<a href="#">
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- //copyright -->

<!-- move top -->
<div class="move-top text-right">
	<a href="#home" class="move-top"> 
		<span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
	</a>
</div>



</body>
<script src="jquery-3.2.1.min.js"></script>
<script src="script1.js"></script>
