<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Bank">
    <meta name="keywords" content="Bank">
    <meta name="author" content="Brad Traversy">
		<title>Log In Details</title>
		<style>
    #scrol {
        background-color: #eee;
        width: 1100px;
        height: 300px;
        border: 1px solid white;
        overflow: scroll;
        padding: 0px;
        margin: 0px;
    }
    .temp{

      width: 1000px;
      margin: 0 auto;
      border:1px solid black;
      padding: 27px;

    }
    table{

      width: 100% ;
      margin: 0 auto;

    }

    table, th, td{
      border: 1px solid #eee;
      border-collapse: collapse;
    }
    th,td{
      padding: 5px;
    }
    table#t01 tr:nth-child(even)
    {
      background:#eee;
    }
    table#t01 tr:nth-child(odd)
    {
      background:#fff;
    }
    table#t01 th{
      background: #1979CA;
      color: white;
    }
    p{
      margin: 10px;
    }
    h1{
      text-align: center;
        padding: 0px;
        margin: 0px;
    }
    hr{

    }
    button {
        background: #F00;
        color: white;
        padding: 1px;
        margin: 0px;
        border: 1px solid red;
        padding-right: 3px;
}

		</style>
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Sonali</span> Bank Limited</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php">Back to Home</a></li>


          </ul>
        </nav>
      </div>
    </header>


			<form action="Log_In_details.php" method="post">
			<h2>User Details</h2><hr>

			</form>
      <div id="scrol">
  		    <table id="t01">
  			        <thead>
  	        <tr>

  	            <th>user_id</th>
  	            <th>user_Name</th>
  	            <th>password</th>

  	        </tr>
  	        </thead>


			<?php
					include("connect.php");


            $sql="SELECT * from user";
            		$r=mysqli_query($con,$sql);

            		while($row=mysqli_fetch_array($r))
            		{
            			$user_id=$row['user_id'];
            			$user_Name=$row['user_Name'];
                  $password=$row['password'];
                  ?>
                  <tr>
             	            <td><?php echo $user_id;  ?></td>
             	            <td><?php echo $user_Name;  ?></td>
             	            <td><?php echo $password;  ?></td>


             	        </tr>

                <?php   } ?>
</table>
</div>



	</body>
</html>
