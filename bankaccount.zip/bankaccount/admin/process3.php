<?php 
  $db = mysqli_connect('localhost', 'root', '', 'bams');
  if (isset($_POST['accountno_check'])) {
  	$accountno = $_POST['accountno'];
  	$sql = "SELECT * FROM account WHERE account_no='$accountno'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "taken";	
  	}else{
  	  echo 'not_taken';
  	}
  	exit();
  }
  if (isset($_POST['customerid_check'])) {
    $customerid = $_POST['customerid'];
    $sql = "SELECT * FROM account WHERE cus_id='$customerid'";
    $results = mysqli_query($db, $sql);
    if (mysqli_num_rows($results) > 0) {
      echo "taken"; 
    }else{
      echo 'not_taken';
    }
    exit();
  }
  if (isset($_POST['nid_check'])) {
    $nid = $_POST['nid'];
    $sql = "SELECT * FROM nid WHERE nid='$nid'";
    $results = mysqli_query($db, $sql);
    if (mysqli_num_rows($results) > 0) {
      echo "taken"; 
    }else{
      echo 'not_taken';
    }
    exit();
  }
  
        if(isset($_POST['submit']))
          {
           
            $accountno=$_POST['accountno'];
            $customerid= $_POST['customerid'];
        
            $accounttype= $_POST['account_type'];
            $balance= $_POST['balance'];
            $nid= $_POST['nid'];
            $Date=date('y-m-d');
            $email=$_POST['email'];
           
          //  echo $pass;
            //$sql = "SELECT * FROM account WHERE account_no='$accountno'";
    //$results = mysqli_query($db, $sql);
    //if (mysqli_num_rows($results) > 0) {
     // echo "exists";  
     // exit();
   // }          else{
      $query="INSERT INTO account(account_no,cus_id,account_type,balance,nid,Date,email)
      values('$accountno','$customerid','$accounttype','$balance','$nid','$Date','$email');";
             if(mysqli_query($db,$query))
             {
              echo "Successful";
             }
            //}
         
          
  	
        
}
?>