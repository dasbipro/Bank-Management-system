<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Bank">
    <meta name="keywords" content="Bank">
    <meta name="author" content="Brad Traversy">
		<title>Deposit Delete</title>
		<style>
			input[type='text'], input[type='password'], select{
				width: 380px;
				height: 20px;
				border: 1px solid black;
			}
			textarea {
				resize: none;
				border: 1px solid black;
			}
			input[type='submit'] {
				background: brown;
				color: white;
				border: 1px solid black;
				width: 380px;
				height: 25px;
			}
		</style>
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Sonali</span> Bank Limited</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php">Back to Home</a></li>



          </ul>
        </nav>
      </div>
    </header>

    <section id="main">
 <div class="container">


			<form action="delete2.php" method="post">
			<h2>Withdraw Balance</h2><hr>

      <table style="width:50%">

        <tr>
          <td><label for="account_no">account_no</label></td>
          <td><input type="text" name="account_no" id="account_no"></td>
        </tr>
      				<tr>

      					<td>
      						<input type="submit" value="Click to submit" name="submit_form">
      					</td>
      				</tr>
      			</table>
			</form>


			 <?php
			 session_start();


			        include("connect.php");
              if(isset($_POST['submit_form']))
              {

									$account_no=$_POST['account_no'];




			      					$ins_sql = "delete from withdraw WHERE account_no= '$account_no'";
			      					$run_sql = mysqli_query($con, $ins_sql);



			               if($run_sql){

			     					echo	$success = "Deleted money successfully!";
									}}








			       ?>

     </div>
</section>
			 <footer>
		     <p>
		Home | Webmail | Contact us | Site Map
		Copyright © 2019 Sonali Bank Limited.
		All rights reserved.</p>
		   </footer>
	</body>
</html>
