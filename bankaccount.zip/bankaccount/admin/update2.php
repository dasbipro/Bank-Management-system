<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Bank">
    <meta name="keywords" content="Bank">
    <meta name="author" content="Brad Traversy">
		<title>Deposit Sections</title>
		<style>
			input[type='text'], input[type='password'], select{
				width: 380px;
				height: 20px;
				border: 1px solid black;
			}
			textarea {
				resize: none;
				border: 1px solid black;
			}
			input[type='submit'] {
				background: brown;
				color: white;
				border: 1px solid black;
				width: 380px;
				height: 25px;
			}
		</style>
		<link rel="stylesheet" href="../css/style.css">
	</head>
	<body>
		<header>
      <div class="container">
        <div id="branding">
          <h1><span class="highlight">Sonali</span> Bank Limited</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.php">Back to Home</a></li>



          </ul>
        </nav>
      </div>
    </header>

    <section id="main">
 <div class="container">


			<form action="update2.php" method="post">
			<h2>Withdraw Balance</h2><hr>
			<table style="width:50%">

				<tr>
					<td><label for="account_no">account_no</label></td>
					<td><input type="text" name="account_no" id="account_no"></td>
				</tr>


        <tr>
				<td><label for="cus_id">cus_id</label></td>
				<td><input type="text" name="cus_id" id="cus_id"></td>
				</tr>
        <tr>
				<td><label for="bank_no">bank_no</label></td>
				<td><input type="text" name="bank_no" id="bank_no"></td>
				</tr>


        <tr>
				<td><label for="amount_withdrawn">amount_withdrawn</label></td>
				<td><input type="text" name="amount_withdrawn" id="amount_withdrawn"></td>
				</tr>

        <tr>
				<td><label for="Date">Date</label></td>
				<td><input type="text" name="Date" id="Date"></td>
				</tr>






				<tr>

					<td>
						<input type="submit" value="Click to submit" name="submit_form">
					</td>
				</tr>
			</table>
			</form>


			 <?php
			 session_start();


			        include("connect.php");
			          if(isset($_POST['submit_form']))
			          {

									$account_no=$_POST['account_no'];
 		 						$cus_id= $_POST['cus_id'];
 		           	$bank_no= $_POST['bank_no'];
								 $amount_withdrawn= $_POST['amount_withdrawn'];
			            $in_sql = "SELECT * FROM account WHERE account_no = '$account_no'";
			      			$ru_sql = mysqli_query($con, $in_sql);
			      			$temp = mysqli_affected_rows($con);
			      			if($temp){
			      				$rows = mysqli_fetch_array($ru_sql);
			      				$balance = $rows['balance'];
			      				$amount = $_POST['amount_withdrawn'];
			      				if($amount>0){
			      					$total = $balance - $amount ;

			      					$ins_sql = "UPDATE account
			      								SET balance = $total
			      								WHERE account_no = '$account_no'";
			      					$run_sql = mysqli_query($con, $ins_sql);
			      					$temp1 = mysqli_affected_rows($con);



			               if($temp1){

			     						$success = "Withdrawn money successfully!";
			     					}else{
			     						$success = "Account number doesn't match!";
			     					}
			     				}else{
			     					$success = "You're fired!";
			     				}
			     			}else{
			     					$success = "Account number doesn't exist!";
			     			}





			     	}


			       ?>

     </div>
</section>
			 <footer>
		     <p>
		Home | Webmail | Contact us | Site Map
		Copyright © 2019 Sonali Bank Limited.
		All rights reserved.</p>
		   </footer>
	</body>
</html>
