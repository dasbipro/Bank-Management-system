    $(function(){
        
        $("#email_error_msg").hide();
        $("#username_error_msg").hide();     
        $("#userid_error_msg").hide();     
        $("#password_error_msg").hide();
     
        
        var error_email=false;
        var error_username=false;
        var error_userid=false;
        var error_password=false;
        

        $("#email").focusout(function(){
            check_email();
        });
        $("#username").focusout(function(){
            check_username();
        // check_username11();
        });
        $("#userid").focusout(function(){
            check_userid();
        // check_username11();
        });
        $("#password").focusout(function(){
            check_password();

        });

        function check_username(){
            var username_length=$("#username").val().length;
            if(username_length < 5 || username_length > 20){
                 $("#username_error_msg").html("Should be between 5-20 Character");
                 $("#username_error_msg").show();
                 error_username=true;
            }
             else{
                    $("#username_error_msg").hide();
                    error_username=false;
               }
            }
           if(error_username==false)
           {
                $.ajax({
                    type:"POST",
                    url:"registration.php",
                    data:'username='+username_val,
                    success:function(data){
                        if(data == 'Yes'){
                            //console.log("yes");
                            $("#username_error_msg1").html('<span id="username_error_msg" class="error_form pl-1">It is already exist, Try again!</span>');
                            //$("#username_error_msg1").show();
                            error_username=true;
                        }
                        else{
                            $("#username_error_msg").hide();
                            //console.log("No");
                            error_username=false;
                        }
                      }
                });
           }   
        }
         function check_password(){
            var password=$("#password").val();
            var password_length =$("#password").val().length;
            if(password<1){
                $("#password_error_msg1").hide();
                $("#password_error_msg").html("The feild is required!");
                $("#password_error_msg").show();
                error_password=true;
            }
            else if(password_length<8){
                $("#password_error_msg1").hide();
                $("#password_error_msg").html("Should be min 8 characters");
                $("#password_error_msg").show();
                error_password=true;
            }
            else{
                $("#password_error_msg").hide();
                error_password=false;
            }
            if(error_password==false){
                $.ajax({
                    type:"POST",
                    url:"registration.php",
                    data:'password='+password,
                    success:function(data){
                        if(data == 'Yes'){
                            $("#password_error_msg1").html('<span id="password_error_msg1" class="error_form">The password 
                        already exist, Try again! </span>');
                            error_password=true;
                            
                        }
                        else{
                            $("#password_error_msg").hide();
                            error_password=false;
                        }
                    }
                });
            }
            
        }

        function check_userid(){
            var userid=$("#userid").val();
            var userid_length=$("#userid").val().length;
            if(userid<1){
                $("#userid_error_msg").hide();
                $("#userid_error_msg").html("The field is required!");
                $("#userid_error_msg").show();
                error_userid=true;
            
            else if(userid_length<1 || userid_length>15 ){
                $("#userid_error_msg").hide();
                $("#userid_error_msg").html("Your userid is not valid! must be 0-15 characters");
                $("#userid_error_msg").show();
                error_userid=true;
            } else{
                    $("#userid_error_msg").hide();
                    error_userid=false;
            }
            }
        if(error_userid==false)
        {
                $.ajax({
                    type:"POST",
                    url:"registration.php",
                    data:'userid='+userid,
                    success:function(data){
                        if(data == 'Yes'){
                            //console.log("yes");
                            $("#userid_error_msg1").html('<span id="userid_error_msg1" class="error_form">It is already exist, Try again!</span>');
                            //$("#username_error_msg1").show();
                            error_userid=true;
                        }
                        else{
                            $("#userid_error_msg").hide();
                            //console.log("No");
                            error_userid=false;
                        }

                    }
                });
        }   
        }
    
        function check_email(){
            var pattern=new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
            var email=$("#email").val();
            if(email<1){
                $("#email_error_msg1").hide();
                $("#email_error_msg").html("The feild is required!");
                $("#email_error_msg").show();
                error_email=true;
            }
            else if(pattern.test($("#email").val())){
                $("#email_error_msg").hide();
                error_email=false;
            }
            else{
                $("#email_error_msg1").hide();
                $("#email_error_msg").html("Invalid email address!!");
                $("#email_error_msg").show();
                error_email=true;
            }
            if(error_email==false){
                $.ajax({
                    type:"POST",
                    url:"registration.php",
                    data:'email='+email,
                    success:function(data){
                        if(data == 'Yes'){
                            $("#email_error_msg1").html('<span id="email_error_msg1" class="error_form">The email is already exist, Try again!</span>');
                            error_email=true;
                        }
                        else{
                            $("#email_error_msg").hide();
                            error_email=false;
                        }
                    }
                });
            }
        }
        function check_password(){
            var password=$("#password").val();
            var password_length =$("#password").val().length;
            if(password<1){
                $("#password_error_msg1").hide();
                $("#password_error_msg").html("The feild is required!");
                $("#password_error_msg").show();
                error_password=true;
            }
            else if(password_length<8){
                $("#password_error_msg1").hide();
                $("#password_error_msg").html("Should be min 8 characters");
                $("#password_error_msg").show();
                error_password=true;
            }
            else{
                $("#password_error_msg").hide();
                error_password=false;
            }
            if(error_password==false){
                $.ajax({
                    type:"POST",
                    url:"registration.php",
                    data:'password='+password,
                    success:function(data){
                        if(data == 'Yes'){
                            $("#password_error_msg1").html('<span id="password_error_msg1" class="error_form">The password 
                        already exist, Try again! </span>');
                            error_password=true;
                            
                        }
                        else{
                            $("#password_error_msg").hide();
                            error_password=false;
                        }
                    }
                });
            }
            
        }


        $("#myform").submit(function(){
            var error_email=false;
            var error_username=false;
            var error_userid=false;
            var error_password=false;
        
            if(error_email==false && error_username==false && error_userid==false && error_password==false){
                return true;
            }
            else{
                return false;
            }
        });

        
    });