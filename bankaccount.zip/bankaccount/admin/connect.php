  <?php

$con= mysqli_connect("localhost","root","","bams");

if(mysqli_connect_errno())
{
  echo "Connection Error".mysqli_connect_error();
}
 ?>
