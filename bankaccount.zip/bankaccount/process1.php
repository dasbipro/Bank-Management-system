
<?php 
   include("connect.php");

  if (isset($_POST['email_check'])) {
    $password = $_POST['email'];
    $sql = "SELECT * FROM admin WHERE email='$email'";
    $sql1 = "SELECT * FROM user WHERE email='$email'";
  $results = mysqli_query($con, $sql);
  $results1 = mysqli_query($con, $sql1);
    if (mysqli_num_rows($results) > 0) {
      echo "taken";	
    }
    else if(mysqli_num_rows($results1) > 0){
        echo "taken";	
    }
    
    else{
      echo 'not_taken';
    }
    exit();
}
  if (isset($_POST['password_check'])) {
    $password = $_POST['password'];
    $sql = "SELECT * FROM admin WHERE password='$password'";
    $sql1 = "SELECT * FROM user WHERE password='$password'";
  $results = mysqli_query($con, $sql);
  $results1 = mysqli_query($con, $sql1);
    if (mysqli_num_rows($results) > 0) {
      echo "taken";	
    }
    else if(mysqli_num_rows($results1) > 0){
        echo "taken";	
    }
    
    else{
      echo 'not_taken';
    }
    exit();
}
        if(isset($_POST['submit']))
          {
            $email=$_POST['email'];
             $password=$_POST['password'];

          //  echo $pass;
          //  $sql = "SELECT * FROM user WHERE username='$username'";
   // $results = mysqli_query($con, $sql);
   /// if (mysqli_num_rows($results) > 0) {
    //  echo "exists";  
    //  exit();
   // }          else{
            $sql="select email,password from admin where email='$email' and password='$password'";
            $sql1="select email,password from  user where email='$email' and password='$password'";
            $r=mysqli_query($con,$sql);
            $r1=mysqli_query($con,$sql1);



            if(mysqli_num_rows($r)>0)
            {
                $_SESSION['email']=$email;
                $_SESSION['admin_login_status']="loged in";
                header("Location:admin/index.php?");
            }

            else if(mysqli_num_rows($r1)>0)
            {
                $_SESSION['email']=$email;
                $_SESSION['employee_login_status']="loged in";
                header("Location:user/index.php?");
            }
            else
            {
                echo "<p style='color: red;'>Incorrect UserId or Password</p>";
            }
          
         
          exit();



  	
        }
        if(isset($_POST['submit']))
          {
            $userid=$_POST['userid'];
             $password=$_POST['password'];
             include("connect.php");
            $sql="select id,password from admin where id='$userid' and password='$password'";
            $sql1="select userid,password from  user where userid='$userid' and password='$password'";
            $r=mysqli_query($con,$sql);
            $r1=mysqli_query($con,$sql1);



            if(mysqli_num_rows($r)>0)
            {
                $_SESSION['id']=$userid;
                $_SESSION['admin_login_status']="loged in";
                header("Location:admin/index.php?");
            }

            else if(mysqli_num_rows($r1)>0)
            {
                $_SESSION['userid']=$userid;
                $_SESSION['employee_login_status']="loged in";
                header("Location:user/index.php?id=$userid");
            }
            else
            {
                echo "<p style='color: red;'>Incorrect UserId or Password</p>";
            }
          
         
          exit();



  	
        }


?>
