 <?php
 			require 'mailer/PHPMailerAutoload.php';
       		$con=mysqli_connect("localhost","root","","restaurant");
			if(isset($_POST['submit']))
			{           		

				$firstname=$_POST['firstname'];
                $lastname=$_POST['lastname'];
                $gender=$_POST['gender'];
                $address=$_POST['address'];
                $email=$_POST['email'];
                $password=$_POST['password'];

            // $username=$data['username'];
            // $password=$data['password'];
            // $email=$data['email'];
            // $date=$data['date'];
            //echo"<script>alert('hello');</script>";
            $token="poiuztrewqasdfghjklmnbvcxy1234567890";
            $token=str_shuffle($token);
            $token=substr($token,0,10);

            $sql="INSERT INTO customer(firstname,lastname,gender,address,email,password,token,confirm_email)
                VALUES('$firstname','$lastname','$gender','$address','$email','$password','$token',0)";

            // $sql="INSERT INTO registration(username,pass,tdate,email,token,comfirm_email)VALUES('$username','$password','$date','$email','$token',0)";
            $result=mysqli_query($con,$sql);
            if($result){
                       // $smt="<script>alert('Insert successfull!!');</script> ";
                // return $smt;
                

                $mail= new PHPMailer;
                $mail->Host='smtp.gmail.com';
                $mail->Port=25;
                $mail->SMTPAuth=true;
                $mail->SMTPSecure='tls';
                $mail->isSMTP();

                $mail->Username='hedaeatulislam00@gmail.com';
                $mail->Password='';

                $mail->setFrom('hedaeatulislam00@gmail.com','Email Verfication');
                $mail->addAddress($email,'Welcome');
                
                $mail->Subject='Please verify email!';


                $mail->isHTML(true);
                $mail->Body="Hi,<br>
                                 Please click on the link below : <br>
                                <a href='http://localhost/ssdlab/sumon/comfirmemail.php?email=$email&token=$token'>Verify Email</a><br>
                            <b>Kind Regard,</b><br>
                                <b>sumon&jubaer&farin.</b>";
                if($mail->send()){
                    $smt="<div class='alert alert-danger text-center' role='alert'>
                    <b>Your registration is successful, Please verify the email and check your inbox!</b>
                    </div>";
                    echo $smt;
                }else{
                    $smt1="<script>alert('Something worng, Please try again!!')</script>";
                    echo  $smt1;
                }
            }
            else{
                $smt="<script>alert('Something is wrong!');</script>";
                echo  $smt;
            }
        }

?>
<?php 
// require 'mailer/PHPMailerAutoload.php';

			// $servername="localhost";
			// $username="";
			// $pass="";
			// $db_name="restaurant";
			// $con=new mysqli($servername,$username,$pass,$db_name);
			// if(isset($_POST['submit']))
			// {
			// 	$firstname=$con->real_escape_string($_POST['firstname']);
			// 	$lastname=$con->real_escape_string($_POST['lastname']);
			// 	$gender=$con->real_escape_string($_POST['gender']);
			// 	$address=$con->real_escape_string($_POST['address']);
			// 	$email=$con->real_escape_string($_POST['email']);
			// 	$password=$con->real_escape_string($_POST['password']);
			// 	$token="poiuztrewqasdfghjklmnbvcxy1234567890";
	  //           $token=str_shuffle($token);
	  //           $token=substr($token,0,10);

   //          $sql="INSERT INTO customer(firstname,lastname,gender,address,email,password,token,confirm_email)
   //              VALUES('$firstname','$lastname','$gender','$address','$email','$password','$token',0)";

   //              $headers="MIME-version: 1.0" . "\n\n";
   //              $headers="Content-type:text/html;charset=UTF-8" ."\n\n";
   //              $headers='From:<info@sitespeck.com>'."\n\n";
   //              $subject="verify Your email";
				

   //              $messege='<p>Hi'.$email.',<br>Pleasea <a href="http://localhost/ssdlab/sumon/confirm.php?email='.$email.'$token='.$token.'"> click here </a> to confirm your email address.</p>';

   //              mail($email,$subject,$messege,$headers);

   //              $msg="Your have been registration.Please confirm your email address.";
   //          }

		?>
 
 <!DOCTYPE html>
	<html>
			<head>
				<meta charset="utf-8">
				<meta name="viewport" content="width=device-width">
				<meta name="description" content="Affordable and professional web design">
				<meta name="keywords" content="web design, affordable web design, professional web design">
				<meta name="author" content="Brad Traversy">
				<title>Web Deisgn | Menu</title>
				<link rel="stylesheet" href="css/style2.css">
				<link rel="stylesheet" href="css/bootstrap.min.css">
				<script src="js/jquery.js"></script>
				<script src="js/main.js"></script>
			  </head>			
			  	  <body>
					<header>
						  <div class="container">
							<div id="branding">
							  <h1><ul><li><a href="index.php">Restaurant Management System</a></li></ul></h1>
							</div>
							<nav>
							<ul>
								<li><a href="index.php">Home</a></li>
								 <li><a href="signup.php">Registration</a></li>
								<li><a href="login.php">LOGIN</a></li>
								<li><a href="contact.php">Contact Us</a></li>
							</ul>
							</nav>
						  </div>
				</header>

<div class="pera" align="center">
	<div class="head">
				<img class="dividerline" src="img/sep.png" alt="">
				<h2>Registration Form </h2>
				<img class="dividerline" src="img/sep.png" alt="">
	</div>
<!-- 			<?php 
			if($msg!=""){
				echo '<div class="alert alert-success">'.$msg.'</div>';
			}
		 ?>
 -->		<form id="myform" action="signup.php" method="post">
	
		<table>
			<tr>
				<td><input type="text" id="firstname" name="firstname" placeholder="Enter Firstname" required="1"></td>
				<td><span class="error_form" id="firstname_error_msg"></span></td>
				<td id=" firstname_error_msg1"></td>


			</tr>
			<tr>
				<td><input type="text" id="lastname" name="lastname" placeholder="Enter Lastname" required="1"></td>
				<td><span class="error_form" id="lastname_error_msg"></span></td>
				<td id=" lastname_error_msg1"></td>
			</tr>
			<tr>
				<td id="gender"> Gender:
					<input type="radio" name="gender" value="male">male
					<input type="radio" name="" value="female">Female
					
				</td>
			</tr>
			
			<tr>
				<td><input type="text" id="address" name="address" placeholder="Enter Address"  required="1"></td>
				<td><span class="error_form" id="address_error_msg"></span></td>
				<td id="address_error_msg1"></td>
			</tr>
			<tr>
				<td><input type="email" id="email" name="email" placeholder="Enter E-mail Address"  required="1"></td>
				<td><span class="error_form" id="email_error_msg"></span></td>
				<td id="email_error_msg1"></td>
			</tr>
				
				<td><input type="password" id="password" name="password" placeholder="Enter Password"  required="1"></td>
				<td><span class="error_form" id="password_error_msg"></span></td>
				<td id="password_error_msg1"></td>
			</tr>
			<tr>
				<td><input type="password" id="confirm_password"name="confirm_password" placeholder="Confirm Password"  required="1"></td>
				<td><span class="error_form" id="confirm_pass_error_msg"></span></td>
							</tr>
			<tr>
				<td><input class="btn-info" type="submit" name="submit" value="submit"></td>		
				<td></td>
			</tr>
		</table>
		<div class="form-group row">
        <div class="col-md-6 offset-md-4 mt-3">
        <small >Already have an account?</small>
        <a href="login.php" class="signup">Login</a>
        </div>
        </div>
	</form>

	</div>
	   <footer>
	  	 	<p>Developed By : University students</p>
	    	<p>Copyright &copy; 2019</p>
	    </footer>
	      <script src="js/vendor/modernizr-3.7.1.min.js"></script>
  <script src="js/jquery.js"></script>
  <script>window.jQuery || document.write('<script src="js/vendor/jquery-3.4.1.min.js"><\/script>')</script>
  <script src="RegFormValidation.js"></script>
  <script src="js/jquery.js"></script>
  <script src="js/main.js"></script>

  <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
  <script>
    window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
    ga('create', 'UA-XXXXX-Y', 'auto'); ga('set','transport','beacon'); ga('send', 'pageview')
  </script>
	</body>	
</html>				