<?php 
  $db = mysqli_connect('localhost', 'root', '', 'bams');
  if (isset($_POST['username_check'])) {
  	$username = $_POST['username'];
  	$sql = "SELECT * FROM user WHERE user_Name='$username'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "taken";	
  	}else{
  	  echo 'not_taken';
  	}
  	exit();
  }
  if (isset($_POST['userid_check'])) {
    $userid = $_POST['userid'];
    $sql = "SELECT * FROM user WHERE user_id='$userid'";
    $results = mysqli_query($db, $sql);
    if (mysqli_num_rows($results) > 0) {
      echo "taken"; 
    }else{
      echo 'not_taken';
    }
    exit();
  }
  if (isset($_POST['email_check'])) {
  	$email = $_POST['email'];
  	$sql = "SELECT * FROM user WHERE email='$email'";
    $results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  echo "taken";	
  	}else{
  	  echo 'not_taken';
  	}
  	exit();
  }
        if(isset($_POST['save']))
          {
            $email=$_POST['email'];
            $user_Name=$_POST['username'];
            //  echo $name;-->
  
            $user_id= $_POST['userid'];
            //echo $email;
            

            $password=$_POST['password'];

          //  echo $pass;
            $sql = "SELECT * FROM user WHERE username='$username'";
    $results = mysqli_query($db, $sql);
    if (mysqli_num_rows($results) > 0) {
      echo "exists";  
      exit();
    }          else{
      $query="INSERT INTO user(email,user_Name,user_id,password)
             values('$email','$user_Name','$user_id','$password')";
             if(mysqli_query($db,$query))
             {

            echo "Successful";
             }
          }
         
          exit();



  	
  }

?>